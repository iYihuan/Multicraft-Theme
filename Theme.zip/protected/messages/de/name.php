﻿<?php

return array('short'=>'zh', 'english'=>'Chinese', 'local'=>'简体中文');
