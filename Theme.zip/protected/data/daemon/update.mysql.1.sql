alter table `server` add `daemon_id` integer not null default 1;
