alter table `server` add `start_memory` integer not null default 0;
